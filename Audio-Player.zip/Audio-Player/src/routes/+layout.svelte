<script>
	import '../app.postcss';
</script>

<svelte:head><title>Zika_Player</title></svelte:head>
<slot />

<style>
	:root {
		text-shadow: 1px 1px 2px rgba(255, 255, 255, 0.295), 0 0 25px rgb(0, 0, 0),
			0 0 5px rgba(20, 235, 20, 0.39);
	}
</style>
